package bcr.com.ecs.getgpslocation;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Button getLL, location;
    TextView showAddr;
    TextView lat;
    TextView lon;

    String lat1, long1;

    // GPSTracker class
    Geocoder geocoder;
    GPSTracker gps;
    List<Address> addresss;
    Context mContext;
    boolean flag = false;

    double latitude;
    double longitude;
    Handler handler = new Handler();

    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mContext = this;
        lat = (TextView) findViewById(R.id.tv_latt);
        lon = (TextView) findViewById(R.id.tv_long);
        showAddr = (TextView) findViewById(R.id.tv_addr);
        location = (Button) findViewById(R.id.btn_location);
        getLL = (Button) findViewById(R.id.getLL);

        getLocation();


        /*handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //Do something after 100ms
                Toast.makeText(MainActivity.this, "check", Toast.LENGTH_SHORT).show();
                gps = new GPSTracker(mContext, MainActivity.this);

                if (gps.canGetLocation()) {
                    if (latitude == 0.0 && longitude == 0.0) {
                        fetchAddress();
                    }
                }
                handler.postDelayed(this, 5000);
            }
        }, 8000);*/
        runnable = new Runnable() {
            @Override
            public void run() {
                //Do something after 100ms
                Toast.makeText(MainActivity.this, "check", Toast.LENGTH_SHORT).show();
                gps = new GPSTracker(mContext, MainActivity.this);

                if (gps.canGetLocation()) {
                    if (latitude == 0.0 && longitude == 0.0) {
                        fetchAddress();
                    }else {
                        handler.removeCallbacks(runnable);
                    }
                }
                if (latitude == 0.0)
                    handler.postDelayed(this, 5000);
            }
        };

        handler.postDelayed(runnable, 5000);

    }


    public void getLocation() {
        if (ContextCompat.checkSelfPermission(mContext,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(mContext,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);

        } else {
            //Toast.makeText(mContext, "You need have granted permission", Toast.LENGTH_SHORT).show();
            gps = new GPSTracker(mContext, MainActivity.this);

            // Check if GPS enabled

            if (gps.canGetLocation()) {

                fetchAddress();
            } else {
                gps.showSettingsAlert();
            }
        }

    }

    int value=100;
    public void fetchAddress() {

        latitude = gps.getLatitude();
        longitude = gps.getLongitude();

        if (latitude!=0.0){
            value=2;
        }else {
            value=100;
        }
        if (value==2) {
            Intent intent = new Intent(MainActivity.this, WeatherActivity.class);
            intent.putExtra("lat", latitude);
            intent.putExtra("lng", longitude);
            startActivity(intent);
        }
        //Toast.makeText(getApplicationContext(),"Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();

        lat1 = Double.toString(latitude);
        long1 = Double.toString(longitude);
        lat.setText(lat1);
        lon.setText(long1);

        try {
            geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
            addresss = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresss != null && addresss.size() > 0) {
                handler.removeCallbacks(runnable);
                String address = addresss.get(0).getAddressLine(0);
                addresss.get(0).getAdminArea();
                String city = addresss.get(0).getLocality();
                showAddr.setText(city);
                String state = addresss.get(0).getAdminArea();
                String country = addresss.get(0).getCountryName();
                String postalCode = addresss.get(0).getPostalCode();
                showAddr.setText("complete address = " + address + "\nCity = " + city + "\nState = " + state + "\n SubAdmin Area = " + addresss.get(0).getSubAdminArea()
                        + "\nSub Locality = " + addresss.get(0).getSubLocality() + "\nThoroughfare =  " + addresss.get(0).getThoroughfare() + "\nPincode = " + addresss.get(0).getPostalCode());
                // Toast.makeText(getApplicationContext(), "Your address is: " + address + " " + city + " " + state + "\n" + country + " " + postalCode, Toast.LENGTH_LONG).show();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*@Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "OnResume", Toast.LENGTH_SHORT).show();
        if (flag)
            getLocation();
    }*/

    /*@Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "OnPause", Toast.LENGTH_SHORT).show();
        flag = true;
    }*/

    /*@Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "OnStop", Toast.LENGTH_SHORT).show();
    }*/


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.

                if (grantResults.length > 0

                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    gps = new GPSTracker(mContext, MainActivity.this);

                    // Check if GPS enabled

                    if (gps.canGetLocation()) {

                        double latitude = gps.getLatitude();
                        double longitude = gps.getLongitude();

                        // \n is for new line

                        Toast.makeText(getApplicationContext(),
                                "Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
                    } else {
                        // Can't get location.

                        // GPS or network is not enabled.

                        // Ask user to enable GPS/network in settings.

                        gps.showSettingsAlert();
                    }

                } else {

                    // permission denied, boo! Disable the

                    // functionality that depends on this permission.
                    Toast.makeText(mContext, "You need to grant permission", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }
}