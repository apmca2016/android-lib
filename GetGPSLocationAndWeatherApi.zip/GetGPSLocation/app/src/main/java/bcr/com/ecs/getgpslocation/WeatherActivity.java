package bcr.com.ecs.getgpslocation;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class WeatherActivity extends AppCompatActivity {

    public static TextView tvplace;
    public static TextView tvtempratue;
    public static  TextView tvcountry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle=getIntent().getExtras();
       // double lat1=bundle.getDouble("lat");
      //  double long1=bundle.getDouble("lng");
        setContentView(R.layout.activity_weather);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        tvplace = (TextView) findViewById(R.id.tv_place);
        tvtempratue = (TextView) findViewById(R.id.tv_temprature);
        tvcountry = (TextView)findViewById(R.id.tv_country);

        DownloadTask task = new DownloadTask();
  //      task.execute("http://samples.openweathermap.org/data/2.5/weather?lat=" + lat1 + "&lon=" + long1 + "&appid=8a9d92a07da7115a0dce353fc45a101d");

        task.execute("http://api.openweathermap.org/data/2.5/weather?zip=208014,in&appid=8a9d92a07da7115a0dce353fc45a101d");

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

