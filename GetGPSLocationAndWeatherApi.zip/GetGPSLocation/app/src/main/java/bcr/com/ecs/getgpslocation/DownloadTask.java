package bcr.com.ecs.getgpslocation;

import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by ECS-27 on 10-02-2018.
 */

public class DownloadTask extends AsyncTask<String, Void, String> {



    @Override
    protected String doInBackground(String... urls) {

        String result = "";
        URL url;
        HttpURLConnection urlconnection = null;

        try {
            url = new URL(urls[0]);

            urlconnection = (HttpURLConnection) url.openConnection();
            InputStream in = urlconnection.getInputStream();
            InputStreamReader reader = new InputStreamReader(in);
            int data = reader.read();
            while (data != -1) {
                char current = (char) data;
                result = result + current;
                data = reader.read();
            }
            return result;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        try {
            JSONObject jsonobject = new JSONObject(result);

            JSONObject weatherData = new JSONObject(jsonobject.getString("main"));

            JSONObject wData = new JSONObject(jsonobject.getString("sys"));

            Double temp = Double.parseDouble(weatherData.getString("temp"));

            String country = wData.getString("country");

            int tempInt = (int) (temp * 1.8 - 459.67);

            String placeName = jsonobject.getString("name");

            WeatherActivity.tvplace.setText(placeName);
            WeatherActivity.tvtempratue.setText(String.valueOf(tempInt));
            WeatherActivity.tvcountry.setText(country);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
