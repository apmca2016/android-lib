package retro.demo.com.retrofittutorial;


import retro.demo.com.pojos.Currency;
import retro.demo.com.pojos.CurrencyFormat;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import retrofit2.http.Url;

/**
 * Created by ECS-27 on 08-01-2018.
 */

public interface CustomApi {

    String CURRENCY_BASE_URL = "https://api.fixer.io/";


    /*@GET("latest?base=USD")
    Call<Currency> getCurrencyBasedOnUSD();*/

    @GET("latest?")
    Call<Currency> getCurrency(@Query("base") String base);

    @GET()
    Call<Currency> getALLCurrencyByDate(@Url() String str);

    @GET("latest?")
    Call<CurrencyFormat> getALLCurrencyBySymbol(@Query("symbols") String base);
}
